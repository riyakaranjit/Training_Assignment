import pyodbc
from pyodbc import Error, OperationalError

from sqlite_crud import SqliteConnection
import config


class SqLServerConnection(SqliteConnection):
    def __init__(self, db_name):
        """
        Create a connection to the SQL Server Database.
        :param db_name: Name of the database you want to connect to.
        """
        self.conn = None
        try:
            connection_string = ("Driver={"+config.DATABASE_CONFIG["Driver"]+"};"
                                 "Server="+config.DATABASE_CONFIG["Server"]+";"
                                 "Database=" + db_name + ";"
                                 "UID="+config.DATABASE_CONFIG["UID"]+";"
                                 "PWD="+config.DATABASE_CONFIG["Password"]+";")
            self.conn = pyodbc.connect(connection_string)
            self.cur = self.conn.cursor()
            print('SQL server connected')
        except Error as e:
            print("New SQL server connection Error", e)

    def sql_server_table_creation(self):
        """
        Create a Student and Gender  table in the sql server database
        :return:
        """
        file = open(config.CREATE_SQLSERVER_TABLES, 'r')
        sqlFile = file.read()
        file.close()
        # all SQL commands (split on ';')
        sqlCommands = sqlFile.split(';')
        try:
            for command in sqlCommands:
                self.cur.execute(command)
            print('Gender Table created successfully')
            print('Student Table created successfully')

        except (Error, OperationalError) as e:
            print("New connection or table creation Error", e)

    def delete_record(self):
        """
        Delete the existing table in the Student record.
        :return:
        """
        student_id = input('Enter Student Id you want to delete: ')

        try:
            select_delete_query = "Select * From Student Where StudentId = ?"
            self.cur.execute(select_delete_query, [student_id])
            item = self.cur.fetchone()
            print('Student Data Fetched for Id = ', student_id)
            self.return_student_table(item)
            confirm = input('Are you sure to delete this record (Y/N)?')

            # Delete after confirmation
            if confirm.lower() == 'y':
                deleteQuery = "Delete From Student Where StudentId = ?"
                reset_student_id = '''CREATE TRIGGER sampleDeleteTrigger
                                        ON Student
                                        FOR DELETE
                                    AS
                                        DECLARE @maxID int;

                                        SELECT @maxID = MAX(StudentId)
                                        FROM Student;

                                        DBCC CHECKIDENT (Student, RESEED, @maxID)'''
                self.cur.execute(reset_student_id)
                self.cur.execute(deleteQuery, [student_id])
                self.conn.commit()
                print('Student record deleted successfully!')
            else:
                print('Wrong Entry!!!')
        except Error as e:
            print('Table delete error', e)
        finally:
            self.conn.close()
