import pandas as pd
import sqlite3
from sqlite3 import Error, OperationalError

import config


class SqliteConnection:
    def __init__(self, db_name):
        """
        Create a connection to the sqlite server.
        :param db_name: Name of the database you want to connect to.
        """
        self.conn = None
        try:
            self.conn = sqlite3.connect(db_name)
            self.cur = self.conn.cursor()
            print("Sqlite connection successfully")
        except Error as e:
            print("New connection Error", e)

    def sqlite_table_creation(self):
        """
        Create a Student and Gender  table in the sqlite database
        :return:
        """
        file = open(config.CREATE_SQLITE_TABLES, 'r')
        sqlFile = file.read()
        file.close()
        # all SQL commands (split on ';')
        sqlCommands = sqlFile.split(';')

        try:
            for command in sqlCommands:
                self.cur.execute(command)
            print('Student Table created successfully')
            print('Gender Table created successfully')

        except (Error, OperationalError) as e:
            print("Student Table create Error", e)

    def return_gender_id(self, gender: str) -> int:
        """
        Inpput gender and return the ihe gender id.
        :param gender: Specific Gender
        :return: gender id
        """
        if gender.lower() == 'male':
            gender_id = 1
            return gender_id
        elif gender.lower() == 'female':
            gender_id = 2
            return gender_id
        elif gender.lower() == 'unknown':
            gender_id = 3
            return gender_id
        else:
            print("Wrong Choice!!!")
            exit()

    @staticmethod
    def return_student_table(item: tuple):
        """
        Prints a table like structure for Student table
        :param item:
        """
        print('StudentId\t\t Name\t\t\t Age\t\t\t Address\t\t\t GenderId')
        print('----------------------------------------------------------------------------')
        print(f'{item[0]}\t\t\t\t {item[1]} \t\t\t\t{item[2]} \t\t\t{item[3]} \t\t\t\t{item[4]}')
        print('----------------------------------------------------------------------------')

    def create_records(self):
        """
        Insertion of record to the Student Table.
        """
        name = input('Enter Name: ')
        age = input('Enter Age: ')
        address = input('Enter Address: ')
        gender = input('Enter Gender: ')
        try:
            gender_id = self.return_gender_id(gender)
            student_insert_query = "Insert Into Student(Name, Age, Address, GenderId) Values(?,?,?,?)"
            self.cur.execute(student_insert_query, [name.capitalize(), age, address.capitalize(), gender_id])

            # Commit the data
            self.conn.commit()
            print('Student Data Inserted Successfully!')
        except Error as e:
            print('Table insertion error', e)
        finally:
            self.conn.close()

    def read_records(self):
        """
        Read all the records from Student Table.
        """
        select_query = '''SELECT s.StudentId ,s.NAME ,s.AGE , s.ADDRESS ,g.Gender
                            FROM
                            Student s
                            JOIN Gender g ON
                            s.GenderId = g.GenderId
                            '''
        self.cur.execute(select_query)
        print('StudentId\t\t Name\t\t\t Age\t\t\t Address\t\t\t Gender')
        print('----------------------------------------------------------------------------')
        for row in self.cur:
            print(f'{row[0]}\t\t\t\t {row[1]} \t\t\t\t{row[2]} \t\t\t{row[3]} \t\t\t\t{row[4]}')
            print('----------------------------------------------------------------------------')

    def update_record(self):
        """
        Update existing records in the Student Table.
        :return:
        """
        student_id = int(input("Enter the student id you want to update: "))
        try:
            select_update_query = "Select * from Student where StudentId = ?"
            self.cur.execute(select_update_query, [student_id])
            # df = pd.read_sql_query(f"Select * from Student where StudentId = {student_id}", self.conn)
            # print(df)
            item = self.cur.fetchone()
            print('Data Fetched for StudentId = ', student_id)
            self.return_student_table(item)
            print('Enter New Data To Update Student Record: ')
            name = input('Enter Name: ')
            age = input('Enter Age: ')
            address = input('Enter Address: ')
            gender = input('Enter Gender: ')
            gender_id = self.return_gender_id(gender)
            update_query = "Update Student Set Name = ?, Age =?, Address=?, GenderId=? Where StudentId =?"

            # Execute the update update_query
            self.cur.execute(update_query, [name.capitalize(), age, address.capitalize(), gender_id, student_id])
            self.conn.commit()

            select_update_query = "Select * from Student where StudentId = ?"
            self.cur.execute(select_update_query, [student_id])
            # df = pd.read_sql_query(f"Select * from Student where StudentId = {student_id}", self.conn)
            # print(df)
            updated_item = self.cur.fetchone()
            print('Student Data Updated for StudentId = ', student_id)
            self.return_student_table(updated_item)
            print('Student Table Updated Successfully')
        except Error as e:
            print('Table update error', e)
        finally:
            self.conn.close()

    def delete_record(self):
        """
        Delete the existing table in the Student record.
        :return:
        """
        student_id = input('Enter Student Id you want to delete: ')

        try:
            select_delete_query = "Select * From Student Where StudentId = ?"
            self.cur.execute(select_delete_query, [student_id])
            item = self.cur.fetchone()
            print('Student Data Fetched for Id = ', student_id)
            # df = pd.read_sql_query(f"Select * from Student where StudentId = {student_id}", self.conn)
            # print(df)
            self.return_student_table(item)
            confirm = input('Are you sure to delete this record (Y/N)?')

            # Delete after confirmation
            if confirm.lower() == 'y':
                deleteQuery = "Delete From Student Where StudentId = ?"
                reset_student_id = "DELETE FROM `sqlite_sequence` WHERE `name` = 'Student'"
                self.cur.execute(deleteQuery, [student_id])
                self.cur.execute(reset_student_id)
                self.conn.commit()
                print('Student record deleted successfully!')
            else:
                print('Wrong Entry!!!')
        except Error as e:
            print('Table delete error', e)
        finally:
            self.conn.close()
